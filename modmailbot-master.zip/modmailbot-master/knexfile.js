const config = require('./src/config');
module.exports = config.knex;
